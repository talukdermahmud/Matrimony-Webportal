<div class="profile_search1">
     <form>
      <input type="text" class="m_1" name="ne" size="30" required="" placeholder="Enter Profile ID :">
      <input type="submit" value="Go">
     </form>
  </div>